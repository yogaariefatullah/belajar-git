<?php
$name='Calibri';
$type='TTF';
$desc=array (
  'Ascent' => 750,
  'Descent' => -250,
  'CapHeight' => 632,
  'Flags' => 4,
  'FontBBox' => '[-476 -194 1214 952]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 507,
);
$up=-113;
$ut=65;
$ttffile='application/libraries/mpdf/ttfonts/Calibri.ttf';
$TTCfontID='0';
$originalsize=264290;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='calibri';
$panose='8 0 2 15 5 2 2 2 4 3 2 4';
?>