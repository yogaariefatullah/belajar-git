# drone-chooser
Project for my last assignment on college, making an expert system for choosing a drone racing/freestyle parts

This project need to run on a machine that have :
- PHP 5
